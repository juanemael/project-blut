module Main where

main :: IO ()
main = putStrLn "Hello, Haskell 2!"

-- login :: IO ()
-- login = 

data Admin = Admin {email :: String , username :: String , password :: String} 
type ListAdmin = [Admin]

-- menuPilihan :: ListMurid -> IO()
-- menuPilihan murid = do 
--     putStrLn "Masukkan nama murid: "
--     namaMurid <- getLine
--     print namaMurid 
--     putStrLn "Masukkan kelas: "
--     kelas <- getLine
--     print kelas
--     putStrLn "Masukkan nilai: "
--     nilai <- getLine
--     print nilai
--     let newValue = murid ++ [(Murid {nama = namaMurid, kelas = kelas, nilai = read nilai})]
--     print murid
--     main7 newValue

loginMenu = do 
    putStrLn "Please insert your username admin: "
    usernameAdmin <- getLine
    putStrLn "Please insert your password: "
    passwordAdmin <- getLine
    -- readFile "database_admin.txt"
    admin <- readFile "database_admin.txt"
    putStrLn admin
    -- putStrLn $ readFile "database_admin.txt"
    print "Login successful!"


registerMenu :: IO ()
registerMenu = do
    putStrLn "Please create your email admin: " 
    emailAdmin <- getLine
    putStrLn "Please create your username admin: "
    usernameAdmin <- getLine
    putStrLn "Please create your password: "
    passwordAdmin <- getLine
    -- let newValue = (Admin {email = emailAdmin, username = usernameAdmin, password = passwordAdmin})
    writeFile "database_admin.txt" (emailAdmin ++ "," ++ usernameAdmin ++ "," ++ passwordAdmin)
    -- return email
    print "asdasd"

prompt :: String -> IO (IO ())
prompt x = do 
    putStr "What is your " >> putStrLn (x ++ " ?")
    >> getLine 
    >>= \a -> return (putStrLn ("Your " ++ x ++ " is: " ++ a))