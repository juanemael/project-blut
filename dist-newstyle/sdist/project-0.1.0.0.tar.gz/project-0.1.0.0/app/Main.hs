import System.Random 
import Text.Read (readMaybe)
import Control.Monad.Trans.Maybe (MaybeT (MaybeT, runMaybeT))

main :: IO ()
main = mainMenu

-- login :: IO ()
-- login = 

data Admin = Admin {email :: String , username :: String , password :: String} 
type ListAdmin = [Admin]

-- menuPilihan :: ListMurid -> IO()
-- menuPilihan murid = do 
--     putStrLn "Masukkan nama murid: "
--     namaMurid <- getLine
--     print namaMurid 
--     putStrLn "Masukkan kelas: "
--     kelas <- getLine
--     print kelas
--     putStrLn "Masukkan nilai: "
--     nilai <- getLine
--     print nilai
--     let newValue = murid ++ [(Murid {nama = namaMurid, kelas = kelas, nilai = read nilai})]
--     print murid
--     main7 newValue

mainMenu = do
    putStrLn  "(Main Menu) Pilih menu:"
    menuOption <- getLine
    case menuOption of 
        "1" -> do
            registerMenu
        "2" -> do
            loginMenu

userMenu = do
    putStrLn  "(Donor Menu) Pilih menu:"
    menuOption <- getLine
    putStrLn "1. Manage Donor Information "
    putStrLn "2. Validate Donor "
    putStrLn "3. Show all of blood donor information"
    case menuOption of
        "1" -> do
            donorMenu
        -- "2" -> do
        --     validateDonor 
        "3" -> do
            loginMenu
insertDonor = do
    putStrLn "Insert donor number ID (Number): "
    donorID <- getLine
    putStrLn  "Insert donor name (Text):"
    donorName <- getLine
    putStrLn  "Insert donor age (Number):"
    donorAge <- getLine
    putStrLn  "Insert donor weight (Number):"
    donorWeight <- getLine
    putStrLn  "Insert donor blood pressure (Number):"
    donorBloodPressure <- getLine
    putStrLn  "Insert donor hemoglobin level (Number):"
    donorHemoglogbin <- getLine
    putStrLn  "Insert donor surgery status (True/False):"
    donorSurgery <- getLine
    putStrLn  "Insert donor tattoo (True/False):"
    donorTattoo <- getLine
    putStrLn  "Insert donor alcohol status (True/False):"
    donorAlcohol <- getLine
    putStrLn  "Insert donor caffeine status (True/False):"
    donorCaffeine <- getLine
    putStrLn  "Insert donor hiv status (True/False):"
    donorHiv <- getLine
    putStrLn  "Insert donor hepatitis status (True/False):"
    donorHepatitis <- getLine
    putStrLn  "Insert donor syphilis status (True/False):"
    donorSyphilis <- getLine
    putStrLn  "Insert donor malaria status (True/False):"
    donorMalaria <- getLine
    
    -- if(donorMalaria == True) then     appendFile "./app/database_donor.txt" ( donorID ++ " " ++ donorName ++ " " ++ donorAge ++ " " ++ donorWeight ++ " " ++ donorTattoo ++ " " ++ donorSurgery ++ " " ++
    --  donorAlcohol ++ " " ++ donorCaffeine ++ " " ++ donorBloodPressure ++ " " ++ donorHemoglogbin  ++ " " ++ donorHiv ++ " " ++ donorHepatitis ++ " " 
    --  ++ donorSyphilis  ++ " " ++ donorMalaria ++ " " ++ verified ++ "\n") else 
        
    -- verified <- validateDonor ((read donorAge), (read donorWeight), (read donorBloodPressure), (read donorHemoglogbin), donorTattoo, donorSurgery, donorAlcohol,
    --     donorCaffeine, donorSyphilis, donorMalaria)
    -- verified <- validateDonor ((read donorAge), (read donorWeight), (read donorBloodPressure), (read donorHemoglogbin), donorTattoo, donorSurgery, donorAlcohol,
    --     donorCaffeine, donorSyphilis, donorMalaria)

    -- if (validateAge (read donorAge) == False || validateWeight (read donorWeight) == False || validateBloodPressure (read donorBloodPressure) == False || 
    --     validateHemoglobinLevel (read donorHemoglogbin) == False || donorTattoo == "True" || donorTattoo == "true" || donorTattoo == "TRUE" || 
    --     donorSurgery == "True" || donorSurgery == "true" || donorSurgery == "TRUE" || donorAlcohol == "True" || donorAlcohol == "true" || donorAlcohol == "TRUE" ||
    --     donorCaffeine == "True" || donorCaffeine == "true" || donorCaffeine == "TRUE" || donorHiv == "True" || donorHiv == "true" || donorHiv == "TRUE" || 
    --     donorHepatitis == "True" || donorHepatitis == "true" || donorHepatitis == "TRUE" || donorSyphilis == "True" || donorSyphilis == "true" || donorSyphilis == "TRUE" ||
    --     donorMalaria == "True" || donorMalaria == "true" || donorMalaria == "TRUE") 
    -- then donorVerified <- False
    --     -- let x = Murid{verified = False}
    --     --     return x
    -- else
    --     donorVerified <- True

        -- if (validateAge (read donorAge) == False || validateWeight weightStatus == False || validateBloodPressure bloodPressureStatus == False || 
        -- validateHemoglobinLevel hemoglobinLevelStatus == False || validateTattoo tattooStatus == False ||
        -- validateSurgery surgeryStatus == False || validateAlcohol alcoholStatus == False || validateCaffeine caffeineStatus == False || validateHIV hivStatus  == False||
        -- validateHepatitis hepatitisStatus == False || validateSyphilis syphilisStatus == False || validateMalaria malariaStatus == False )
        -- then return False
        --     -- let x = Murid{verified = False}
        --     --     return x
        -- else
        --     return True

    --     if ( read donorAge < 17 || read donorAge > 65) then 
    --         do donorVerify <- False 
    --         else do donorVerify <- True 

    --     if (read weight < 45) then False else True

    --     if (read bloodPressure < 120) then False else True

    --     if (read hemoglobinLevel < 14  || read hemoglobinLevel > 18) then
    --         False
    --     else True

    -- if tattoo' == "True" || tattoo' == "true" || tattoo' == "TRUE" then return True else return False
    -- if surgery' == "True" || surgery' == "true" || surgery' == "TRUE" then return True else return False
    -- if alcohol' == "True" || alcohol' == "true" || alcohol' == "TRUE" then return True else return False
    -- if caffeine' == "True" || caffeine' == "true" || caffeine' == "TRUE" then return True else return False
    -- if hiv' == "True" || hiv' == "true" || hiv' == "TRUE" then return True else return False
    -- if hepatitis' == "True" || hepatitis' == "true" || hepatitis' == "TRUE" then return True else return False
    -- if syphilis' == "True" || syphilis' == "true" || syphilis' == "TRUE" then return True else return False
    -- if malaria' == "True" || malaria' == "true" || malaria' == "TRUE" then return True else return False

    appendFile "./app/database_donor.txt" ( donorID ++ " " ++ donorName ++ " " ++ donorAge ++ " " ++ donorWeight ++ " " ++ donorTattoo ++ " " ++ donorSurgery ++ " " ++
     donorAlcohol ++ " " ++ donorCaffeine ++ " " ++ donorBloodPressure ++ " " ++ donorHemoglogbin  ++ " " ++ donorHiv ++ " " ++ donorHepatitis ++ " " 
     ++ donorSyphilis  ++ " " ++ donorMalaria ++ " " ++ verified ++ "\n")
    userMenu
  
-- randomizeID = x <- randomRIO (0,10)
--     print x 

readSurgery :: MaybeT IO Bool
readSurgery = MaybeT $ do


donorMenu = do
    putStrLn  "(Donor Menu) Pilih menu:"
    menuOption <- getLine
    putStrLn  "1. Insert Donor Information:"
    putStrLn  "2. Update Donor Information:"
    putStrLn  "3. Delete Donor Information:"
    case menuOption of
        "1" -> do
            insertDonor
        -- "2" -> do
            -- updateDonor
        -- "3" -> do
            -- deleteDonor
        "4" -> do
            loginMenu
        -- "2. Validate your patient information " -> do
        --     registerPatient

loginMenu = do 
    putStrLn "Please insert your username admin: "
    usernameAdmin <- getLine
    putStrLn "Please insert your password: "
    passwordAdmin <- getLine
    -- readFile "database_admin.txt"
    -- admin <- readFile "./app/database_admin.txt" 
    -- putStrLn $ readFile "database_admin.txt"
    -- print $ words admin
    -- let x = words admin
    userMenu

registerMenu :: IO ()
registerMenu = do
    putStrLn "Please create your email admin: " 
    emailAdmin <- getLine
    putStrLn "Please create your username admin: "
    usernameAdmin <- getLine
    putStrLn "Please create your password: "
    passwordAdmin <- getLine
    -- let newValue = (Admin {email = emailAdmin, username = usernameAdmin, password = passwordAdmin})
    writeFile "./app/database_admin.txt" (emailAdmin ++ " " ++ usernameAdmin ++ " " ++ passwordAdmin)
    -- return email
    print "You have successfully registered!"

prompt :: String -> IO (IO ())
prompt x = do 
    putStr "What is your " >> putStrLn (x ++ " ?")
    >> getLine 
    >>= \a -> return (putStrLn ("Your " ++ x ++ " is: " ++ a))

-- validateDonor = do
--     a <- getDonorInfo
--     -- print $ words a
--     let b  = splitAt 1 a
--     -- print $ map b
--     print b
-- name :: String, 
-- age :: Int , weight :: Int, bloodPressure :: Int, hemoglobinLevel :: Int, 
-- tattoo :: Bool, surgery :: Bool, alcohol ::  Bool, caffeine :: Bool,  hiv :: Bool,
-- hepatitis :: Bool, syphilis :: Bool, malaria :: Bool, verified :: Bool

validateDonor ageStatus weightStatus bloodPressureStatus hemoglobinLevelStatus surgeryStatus hepatitisStatus syphilisStatus tattooStatus alcoholStatus caffeineStatus malariaStatus hivStatus = do
    if (validateAge ageStatus == False || validateWeight weightStatus == False || validateBloodPressure bloodPressureStatus == False || 
        validateHemoglobinLevel hemoglobinLevelStatus == False || validateTattoo tattooStatus == False ||
        validateSurgery surgeryStatus == False || validateAlcohol alcoholStatus == False || validateCaffeine caffeineStatus == False || validateHIV hivStatus == False||
        validateHepatitis hepatitisStatus == False || validateSyphilis syphilisStatus == False || validateMalaria malariaStatus == False )
        then return False
    else
        return True


validateDonorBool alcoholStatus caffeineStatus hivStatus hepatitisStatus syphilisStatus malariaStatus tattooStatus surgeryStatus = do 
    if (tattooStatus == "True" || tattooStatus == "true" || tattooStatus == "TRUE" || 
        surgeryStatus == "True" || surgeryStatus == "true" || surgeryStatus == "TRUE" || alcoholStatus == "True" || alcoholStatus == "true" || alcoholStatus == "TRUE" ||
        caffeineStatus == "True" || caffeineStatus == "true" || caffeineStatus == "TRUE" || hivStatus == "True" || hivStatus == "true" || hivStatus == "TRUE" || 
        hepatitisStatus == "True" || hepatitisStatus == "true" || hepatitisStatus == "TRUE" || syphilisStatus == "True" || syphilisStatus == "true" || syphilisStatus == "TRUE" ||
        malariaStatus == "True" || malariaStatus == "true" || malariaStatus == "TRUE")  then return False  
    else 
        return True
-- validateDonor Donor {name = nameStatus, age = ageStatus , weight = weightStatus, bloodPressure = bloodPressureStatus, hemoglobinLevel = hemoglobinLevelStatus , 
-- tattoo = tattooStatus, surgery = surgeryStatus, alcohol = alcoholStatus, caffeine = caffeineStatus, hiv = hivStatus,
-- hepatitis = hepatitisStatus, syphilis = syphilisStatus, malaria = malariaStatus, verified = False} = do
--     if (validateAge ageStatus == False || validateWeight weightStatus == False || validateBloodPressure bloodPressureStatus == False || 
--         validateHemoglobinLevel hemoglobinLevelStatus == False || validateTattoo tattooStatus == False ||
--         validateSurgery surgeryStatus == False || validateAlcohol alcoholStatus == False || validateCaffeine caffeineStatus == False || validateHIV hivStatus  == False||
--         validateHepatitis hepatitisStatus == False || validateSyphilis syphilisStatus == False || validateMalaria malariaStatus == False )
--         then return False
--             -- let x = Murid{verified = False}
--             --     return x
--     else
--         return True
        -- let x = Murid{verified = False}
        --     return x

-- validateName (Donor {name = name, verified = verified}) = do
--     if 

validateAge age = 
    if (age < 17 || age > 65) then False else True

validateWeight weight =
    if (weight < 45) then False else True

validateBloodPressure bloodPressure =
    if (bloodPressure < 120) then False else True

validateHemoglobinLevel hemoglobinLevel = do
    if (hemoglobinLevel < 14  || hemoglobinLevel > 18) then
        False
    else True
validateTattoo tattoo = do
    if (tattoo == False) then
        False
    else True
validateSurgery surgery = do
    if (surgery == False) then 
        False
    else True

validateAlcohol alcohol = do
    if (alcohol == False) then 
        False
    else True

validateCaffeine caffeine = do
    if (caffeine == False) then 
        False
    else True

validateHIV hiv = do
    if (hiv == False) then 
        False
    else True

validateHepatitis hepatitis = do
    if (hepatitis == False) then 
        False
    else True

validateSyphilis hepatitis = do
    if (hepatitis == False) then 
        False
    else True

validateMalaria malaria = do
    if (malaria == False) then 
        False
    else True
    

getDonorInfoNameText =  do
    a <- getDonorInfo
    let b  = words a
    return $ head b

getDonorInfoIntBool =  do
    a <- getDonorInfo
    let b  = words a
    return $ tail b
-- getDonorInfoIntBool =  do
--     a <- getDonorInfo
--     let b  = words a
--     return $ tail b

-- getDonorPattern [] = []
-- getDonorPattern (x:xs) 
--     | x > 0 = x : xs 
--     | (x == True || x == False) = getDonorPattern [] 
--     | otherwise = getDonorPattern xs
-- getDonorPattern _ = if(x >0) then x : xs else getDonorPattern xs
-- getDonorInfoIO :: IO [Donor]
-- getDonorInfoIO =  do
--     donor <- readFile "database_donor.txt"
--     let line_donor = lines donor
--     return $ head line_donor

-- arrayToObject :: [a] -> a
arrayToObject (x:xs) = x

ioToObject = do 
    donorObject <- validateDonor2 
    let object = validateDonor2a donorObject
    return object


-- validateDonor2 = do 
--     stringDonor <- getDonorInfo 
--     let a = parseDonor stringDonor
    -- print a

validateDonor2 = do 
    stringDonor <- getDonorInfo 
    -- return $ parseDonor stringDonor
    let a = parseDonor stringDonor
    -- print a
    return $ parseDonor stringDonor


validateDonor2a (x:xs) = x

validateDonor3 a = arrayToObject a >>= \b -> b

parseDonor :: String -> [Donor]
parseDonor content = do
    [donor_id', name', age', weight', bloodPressure', hemoglobinLevel', tattoo', surgery', alcohol', caffeine', hiv', hepatitis', syphilis', malaria' ] <- words <$> lines content
    Just age'' <- return $ readMaybe age'
    Just donor_id'' <- return $ readMaybe donor_id'
    Just weight'' <- return $ readMaybe weight'
    Just bloodPressure'' <- return $ readMaybe bloodPressure'
    Just hemoglobinLevel'' <- return $ readMaybe hemoglobinLevel'
    tattoo'' <- if tattoo' == "True" || tattoo' == "true" || tattoo' == "TRUE" then return True else return False
    surgery'' <- if surgery' == "True" || surgery' == "true" || surgery' == "TRUE" then return True else return False
    alcohol'' <- if alcohol' == "True" || alcohol' == "true" || alcohol' == "TRUE" then return True else return False
    caffeine'' <- if caffeine' == "True" || caffeine' == "true" || caffeine' == "TRUE" then return True else return False
    hiv'' <- if hiv' == "True" || hiv' == "true" || hiv' == "TRUE" then return True else return False
    hepatitis'' <- if hepatitis' == "True" || hepatitis' == "true" || hepatitis' == "TRUE" then return True else return False
    syphilis'' <- if syphilis' == "True" || syphilis' == "true" || syphilis' == "TRUE" then return True else return False
    malaria'' <- if malaria' == "True" || malaria' == "true" || malaria' == "TRUE" then return True else return False
    return (Donor {donor_id = donor_id'', name =name', age = age'' , weight = weight'', bloodPressure = bloodPressure'', hemoglobinLevel = hemoglobinLevel'', 
                   tattoo = tattoo'', surgery = surgery'', alcohol = alcohol'', caffeine = caffeine'',  hiv = hiv'',
                   hepatitis = hepatitis'', syphilis = syphilis'', malaria = malaria'', verified = False })
    

data Donor = Donor {donor_id :: Int, name :: String, 
age :: Int , weight :: Int, bloodPressure :: Int, hemoglobinLevel :: Int, 
tattoo :: Bool, surgery :: Bool, alcohol ::  Bool, caffeine :: Bool,  hiv :: Bool,
hepatitis :: Bool, syphilis :: Bool, malaria :: Bool, verified :: Bool } deriving Show
type ListDonor = [Donor]
getDonorInfo =  do
    donor <- readFile "database_donor.txt"
    let line_donor = lines donor
    return $ head line_donor

-- append :: [Int] -> [Int]
-- append = concatMap digs

-- digs :: Integral x => x -> [x]
-- digs 0 = []
-- digs x = digs (x `div` 10) ++ [x `mod` 10]
